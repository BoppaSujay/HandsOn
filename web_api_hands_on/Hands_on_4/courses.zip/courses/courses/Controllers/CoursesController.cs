﻿using courses.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;


namespace courses.Controllers
{
    public class CoursesController : ApiController
    {
        static List<Course> courses = new List<Course>()
        {
            new Course(){CourseId=1,CourseName="Android",Trainer="Shawn",Fees=12000,CourseDescription="Android is a mobile operating system development"},
            new Course(){CourseId=2,CourseName="ASP .Net",Trainer="Kevin",Fees=10000,CourseDescription="ASP .NET is a open source web development framework"},
            new Course(){CourseId=3,CourseName="JSP",Trainer="Debaratha",Fees=10000,CourseDescription="Java server pages is a technology used for web creations"},
            new Course(){CourseId=4,CourseName="Xamarin.forms",Trainer="Mark John",Fees=15000,CourseDescription="Xmarin forms are cross platform UI tools"}
        };
        public HttpResponseMessage Get([FromUri] string courseName)
        {
            var a = courses.FirstOrDefault(s => s.CourseName == courseName);
            if (a != null)
            {
                return Request.CreateResponse(HttpStatusCode.OK, a);
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.NotFound, $"CorseName not found");
            }
        }
        public HttpResponseMessage Post([FromBody] Course n)
        {
            courses.Add(n);
            return Request.CreateResponse(HttpStatusCode.Created, n);
        }
    }
}
