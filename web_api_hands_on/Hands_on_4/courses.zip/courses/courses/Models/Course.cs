using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace courses.Models
{
    public class Course /*: DbContext*/
    {

        public int CourseId { get; set; }
        public string CourseName { get; set; }
        public string Trainer { get; set; }
        public int Fees { get; set; }
        public string CourseDescription { get; set; }
    }

    



}